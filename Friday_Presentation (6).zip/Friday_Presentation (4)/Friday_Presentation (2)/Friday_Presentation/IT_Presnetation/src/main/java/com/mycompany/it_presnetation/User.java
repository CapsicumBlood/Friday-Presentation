/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it_presnetation;

/**
 *
 * @author Tobin Petersen
 */
public class User {
    private static int loggedInUserID;
    private static String UsernameTexTField;
    private static String passwordTexTField;

    public static int getLoggedInUserID() {
        return loggedInUserID;
    }

    public static void setLoggedInUserID(int user_ID) {
        loggedInUserID = user_ID;
    }

    public static String getLoggedInUserUsername() {
        return UsernameTexTField;
    }

    public static void setLoggedInUserUsername(String username) {
        UsernameTexTField = username;
    }

    public static String getLoggedInUserPassword() {
        return passwordTexTField;
    }

    public static void setLoggedInUserPassword(String password) {
        passwordTexTField = password;
    }
        public static void updateLoggedInUserID() {
        // Retrieve the logged-in user ID from your login process and set it
        // Example: loggedInUserID = <retrieve user ID> 
        }
}
