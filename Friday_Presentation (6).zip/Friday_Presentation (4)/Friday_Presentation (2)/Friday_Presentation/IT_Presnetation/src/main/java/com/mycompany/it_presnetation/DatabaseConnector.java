/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.it_presnetation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Tobin Petersen
 */
public class DatabaseConnector {
    
    
    
    private static final String URL = "jdbc:sqlite:C:/Users/Tobin Petersen/Desktop/CTU Assessments/JD522/JD522_FA2_DB.db";

    
   static {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

     /**
     * Connect to the SQLite database.
     *
     * @return A connection to the SQLite database.
     * @throws SQLException If a database access error occurs.
     */
    public static Connection connectSQLite() throws SQLException {
        return DriverManager.getConnection(URL);
    }
       public static String getUserRole(int userID) {
        String userRole = null;
        String query = "SELECT Role FROM User_Info WHERE User_ID = ?";
        try (Connection connection = connectSQLite();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userID);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    userRole = resultSet.getString("Role");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userRole;
    }
    }

    

